package es.uned.portalreuniones.exception;

public class NicknameFoundException extends Exception {

	private static final long serialVersionUID = -7881319488243053036L;

	public NicknameFoundException(String message) {
		super(message);
	}

}
