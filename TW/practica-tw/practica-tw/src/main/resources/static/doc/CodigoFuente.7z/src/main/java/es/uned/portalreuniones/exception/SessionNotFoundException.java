package es.uned.portalreuniones.exception;

public class SessionNotFoundException extends Exception {

	private static final long serialVersionUID = 8044432145915164891L;

	public SessionNotFoundException(String message) {
		super(message);
	}

}
