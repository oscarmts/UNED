package es.uned.portalreuniones.exception;

public class ElementNotFoundException extends Exception {

	private static final long serialVersionUID = 8044432145915164891L;

	public ElementNotFoundException(String message) {
		super(message);
	}

}
