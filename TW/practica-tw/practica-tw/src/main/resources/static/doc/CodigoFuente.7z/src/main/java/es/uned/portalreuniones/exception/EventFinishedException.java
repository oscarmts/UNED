package es.uned.portalreuniones.exception;

public class EventFinishedException extends Exception {

	private static final long serialVersionUID = 6008225420041385121L;

	public EventFinishedException(String message) {
		super(message);
	}
}
