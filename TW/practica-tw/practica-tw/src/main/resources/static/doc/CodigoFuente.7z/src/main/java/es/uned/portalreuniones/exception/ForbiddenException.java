package es.uned.portalreuniones.exception;

public class ForbiddenException extends Exception {

	private static final long serialVersionUID = -6051714393647543243L;

	public ForbiddenException(String message) {
		super(message);
	}
}
