package es.uned.portalreuniones.exception;

public class RoomNameFoundException extends Exception {

	private static final long serialVersionUID = -4442746241377950897L;

	public RoomNameFoundException(String message) {
		super(message);
	}

}
